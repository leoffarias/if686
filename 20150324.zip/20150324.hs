menorMaior :: Int -> Int -> Int -> (Int, Int)
menorMaior x y z = (a, c)
 where (a, c) = (min (min x y) z, max (max x y) z)
 
{-ordenaTripla :: (Int, Int, Int) -> (Int, Int, Int)
ordenaTripla (x, y, z) = (a, c, b)
 where (a, b) = menorMaior x y z
       c = -}

 {- outro modo:
menorMaior3 :: Int -> Int -> Int -> (Int, Int)
menorMaior3 x y z
 | (x > y) && (x > z) && (y > z) = (z, x)
 | (x > y) && (x > z) = (y, x)
 | (y > x) && (y > z) && (x > z) = (z, y)
 | (y > x) && (y > z) = (x, y)
 | (y > x) = (x, z)
 | otherwise = (y, z)-}
 
menorMaior2 :: Int -> Int -> Int -> (Int, Int, Int)
menorMaior2 x y z
 | (x > y) && (x > z) && (y > z) = (z, y, x)
 | (x > y) && (x > z) = (y, z, x)
 | (y > x) && (y > z) && (x > z) = (z, x, y)
 | (y > x) && (y > z) = (x, z, y)
 | (y > x) = (x, y, z)
 | otherwise = (y, x, z)
 
ordenaTripla2 :: (Int, Int, Int) -> (Int, Int, Int)
ordenaTripla2 (x, y, z) = (a, b, c)
 where (a, b, c) = menorMaior2 x y z
