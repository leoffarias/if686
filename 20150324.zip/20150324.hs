menorMaior :: Int -> Int -> Int -> (Int, Int)
menorMaior x y z = (a, c)
 where (a, c) = (min (min x y) z, max (max x y) z)
 
{-ordenaTripla :: (Int, Int, Int) -> (Int, Int, Int)
ordenaTripla (x, y, z) = (a, c, b)
 where (a, b) = menorMaior x y z
       c = -}

 {- outro modo:
menorMaior3 :: Int -> Int -> Int -> (Int, Int)
menorMaior3 x y z
 | (x > y) && (x > z) && (y > z) = (z, x)
 | (x > y) && (x > z) = (y, x)
 | (y > x) && (y > z) && (x > z) = (z, y)
 | (y > x) && (y > z) = (x, y)
 | (y > x) = (x, z)
 | otherwise = (y, z)-}
 
menorMaior2 :: Int -> Int -> Int -> (Int, Int, Int)
menorMaior2 x y z
 | (x > y) && (x > z) && (y > z) = (z, y, x)
 | (x > y) && (x > z) = (y, z, x)
 | (y > x) && (y > z) && (x > z) = (z, x, y)
 | (y > x) && (y > z) = (x, z, y)
 | (y > x) = (x, y, z)
 | otherwise = (y, x, z)
 
ordenaTripla2 :: (Int, Int, Int) -> (Int, Int, Int)
ordenaTripla2 (x, y, z) = (a, b, c)
 where (a, b, c) = menorMaior2 x y z
 
{- Exemplo: biblioteca -}

type Pessoa = String
type Livro = String
type BancoDados = [(Pessoa, Livro)]

baseExemplo :: BancoDados
baseExemplo = [("Sergio","O Senhor dos Aneis"), ("Andre","Duna"), ("Fernando","Jonathan Strange & Mr. Norrell"),  ("Fernando","A Game of Thrones")] -- livros emprestados

livros :: BancoDados -> Pessoa -> [Livro]
livros bd pes = [b | (a,b) <- bd, a == pes]

{-outro modo
livros [] pp = []
livros ((p,l):as) pp
 | pp == p = l:livros as
 | otherwise = livros as
-}

emprestimos :: BancoDados -> Livro -> [Pessoa]
emprestimos bd livro = [a | (a,b) <- bd, b == livro]

emprestado :: BancoDados -> Livro -> Bool
emprestado [] _ = False
emprestado ((p, l):as) livro
 | l == livro = True
 | otherwise = emprestado as livro

qtdEmprestimos :: BancoDados -> Pessoa -> Int
qtdEmprestimos [] _ = 0
qtdEmprestimos ((p, l):as) pessoa
 | pessoa == p = qtdEmprestimos as pessoa + 1
 | otherwise = qtdEmprestimos as pessoa